<?php
define("correct_token", "ndjbdxc9898ccdmcdcdcdc22op2op2nd2099ddd9cdd99d9d9c333cccdccxxscddxxdssndndndnnjnji9i");
define("_driver_", "mysql");
define("_host_", "localhost");
define("_database_", "php_project_os42");
define("_username_", "root");
define("_password_", "");
define("_max_username_length_", 255);
